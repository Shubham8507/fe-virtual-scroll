import React, { useEffect, useCallback } from 'react';
import { List } from 'react-virtualized';
import { useSelector, useDispatch } from 'react-redux';
import { CircularProgress, Box } from '@mui/material';
import styled from 'styled-components';
import { fetchItems, incrementPage } from '../redux/slices/itemsSlice';
import Card from './Card';

const Item = styled.div`
  padding: 16px;
  border-bottom: 1px solid #ddd;
`;

const StyledProductImage = styled("img")`
  width: 100px;
  height: 100px;
  display: flex;
  justify-content: center;
  position: relative;
`;

const StyledValueConatiner = styled.div`
  text-align: center;
`;


const StyledLoaderContainer = styled(Box)`
    position: absolute; 
    bottom: 10; 
    left: 50%;
`;


const VirtualScrollList = (props) => {
    const dispatch = useDispatch();
    const { items, loading, page } = useSelector((state) => state.items);

    // Fetch items on page load / scrolling
    useEffect(() => {
        console.log("page", page)
        dispatch(fetchItems(page));
    }, [dispatch, page]);

    // Load more items when reaching the bottom
    const handleScroll = useCallback(({ clientHeight, scrollHeight, scrollTop }) => {
        if (scrollHeight - scrollTop <= clientHeight + 200 && !loading) {
            dispatch(incrementPage());
            dispatch(fetchItems(page + 1));
        }
    }, [dispatch, loading, page]);

    const rowRenderer = ({ index, key, style }) => (
        <Item key={key} style={style}>
            {/* <StyledProductImage src={`${items[index].thumbnailUrl}`} alt="" loading="lazy" />

            <StyledValueConatiner>{items[index]?.title}</StyledValueConatiner> */}
            <Card item={items[index]} />
        </Item>
    );


    const getBodyHeight = () => {
        let heightOfInnerTable = window.innerHeight - 90;
        return `${heightOfInnerTable}`;
    };


    return (
        <Box>
            <List
                height={500}
                rowHeight={250}
                width={400}
                rowCount={items.length}
                rowRenderer={rowRenderer}
                onScroll={handleScroll}
                style={{
                    // display: 'flex',
                    // alignItems: 'center',
                }}
            />
            {loading && (
                <StyledLoaderContainer>
                    <CircularProgress />
                </StyledLoaderContainer>
            )}
        </Box>
    );
};

export default VirtualScrollList;
