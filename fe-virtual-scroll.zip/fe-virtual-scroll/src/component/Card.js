import React from 'react';
import styled from 'styled-components';

// Styled Components
const CardContainer = styled.div`
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    width: 300px;
    margin: 10px;
    
    transition: transform 0.3s ease-in-out;
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
    &:hover {
        transform: scale(1.05);
    }
`;

const CardImage = styled.img`
    width: 80px;
    height: 80px;
`;

const CardContent = styled.div`
    padding: 15px;
`;

const CardTitle = styled.h2`
    font-size: 18px;
    font-weight: bold;
    margin: 0 0 10px;
`;

const CardDescription = styled.p`
    font-size: 14px;
    color: #555;
`;

const Card = (props) => {
    let { thumbnailUrl, title, description } = props.item;
    return (
        <CardContainer>
            <CardImage src={thumbnailUrl} alt={title} />
            <CardContent>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardContent>
        </CardContainer>
    );
};

export default Card;
