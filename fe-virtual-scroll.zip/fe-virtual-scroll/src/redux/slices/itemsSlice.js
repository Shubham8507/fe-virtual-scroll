import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchItems = createAsyncThunk(
    'items/fetchItems',
    async (page) => {
        // const response = await axios.get(`http://localhost:4000/items?page=${page}&limit=100`);
        const response = await axios.get(`https://jsonplaceholder.typicode.com/photos?_limit=50&_page=${page}`);

        return response.data;
    }
);

const itemsSlice = createSlice({
    name: 'items',
    initialState: {
        items: [],
        loading: false,
        page: 1,
        error: null,
    },
    reducers: {
        incrementPage(state) {
            state.page += 1;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchItems.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchItems.fulfilled, (state, action) => {
                state.items = [...state.items, ...action.payload];
                state.loading = false;
            })
            .addCase(fetchItems.rejected, (state, action) => {
                state.error = action.error.message;
                state.loading = false;
            });
    },
});

export const { incrementPage } = itemsSlice.actions;
export default itemsSlice.reducer;
