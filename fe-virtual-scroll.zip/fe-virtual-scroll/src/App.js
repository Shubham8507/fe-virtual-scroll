import React from 'react';
import { Container, Grid } from '@mui/material';
import VirtualScrollList from './component/VirtualScrollList';


function App() {
  return (
    <Container>
      <Grid container spacing={1}>
        <Grid item xs={12}>
          <h3>Virtual Scrolling</h3>
        </Grid>
        <Grid item xs={12}>
          <VirtualScrollList />
        </Grid>
      </Grid>
    </Container>
  );
}

export default App;